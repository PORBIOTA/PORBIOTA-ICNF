Creates a CSV with the results obtained by cross referencing the species name in one CSV with those from GBIF API.
Aditionally it creates an occurenceID for each occurence.

IMPORTANT
#####################################################################################################################
The input file can have any number of columns, but the Species collumn must be named "scientificName".
######################################################################################################################

These fields are filled based on the original CSV species name:

scientificName
genus
specificEpithet
infraspecificEpithet

All the other fields are based on GBIF data. The acceptedNameUsage uses the latest name of the species and not
necessarily the one that matches the scientificName given.
	
To use, edit the "SpeciesExtractor Runner (EDIT ME).bat" with notepad and change the "Kingdom" to the kingdom of the species being searched.
If there is more than one kingdom, simply put "".
Then change "Input File.csv" into your input file and "Output File.csv" to where you wish to save the results (both with quotes). 
Save the file.
Finally, double click "LocationExtractor Runner (EDIT ME).bat" and a window should appear showing the progress.

Example:
java -jar LocationExtractor.jar "Animalia" "C:/input file.csv" "C:/output file.csv"

The output file is in UTF-8.

There is no need to clean duplicates, the program does not repeat calls.

The order and number of rows of the results is preserved, so simply joining the produced table to the original one is OK.

