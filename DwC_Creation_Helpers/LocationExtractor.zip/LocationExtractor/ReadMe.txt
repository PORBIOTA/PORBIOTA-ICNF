Creates a CSV with the results obtained by inputing WGS84 coordinates into the OpenStreetMaps API.

############################IMPORTANT##########################################################
The input file can have any number of columns, but the Longitude collumn must be named 
"decimalLongitude" and the Latitude "decimalLatitude".
################################################################################################

The following is extracted:

		Hamlet	
		Borough
		Village
		Town
		City District
		Municipality
		County
		State
		Archipelago
		Country
		Country Code	

	Additionally, it creates the DwC columns for Portugal and Spain, based on the following set of rules: 

	Portugal:		
		stateProvince = county
		county = there is no county for Portugal
		municipality = municipality, if blank, city, if blank, town
		locality = hamlet, if blank, village, if blank, city_district, if blank, town, if blank, city
		islandGroup = Archipelago
	
	

	Spain:	
		stateProvince = state
		county = county or province
		municipality = municipality, if blank, city, if blank, town, if blank, village
		locality = hamlet, if blank, borough, if blank, village, if blank, town, if blank, city
		islandGroup = Archipelago
			
To use, edit the "LocationExtractor Runner (EDIT ME).bat" with notepad and change the "Input File.csv" into your input file 
and "Output File.csv" to where you wish to save the results (both with quotes).
Save the file.
Then, double click "LocationExtractor Runner (EDIT ME).bat" 
and a window should appear showing the progress.

Example:
java -jar LocationExtractor.jar "C:/input file.csv" "C:/output file.csv"

The output file is in UTF-8.

There is no need to clean duplicates, the program does not repeat calls.

The order and number of rows of the results is preserved, so simply joining the produced table to the original one is OK.
