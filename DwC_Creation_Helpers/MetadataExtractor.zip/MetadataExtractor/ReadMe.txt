Creates a .txt with the metadata info extracted from a .csv darwinCore-like file.

The following is extracted: 
###############IMPORTANT####################
 Header names must match those given here
###############IMPORTANT####################

Number of rows [+1 if you wish to include the header]
Number of species and names [Based on "acceptedNameUsage"]
Number of genus and names [Based on "genus"]
Number of families and names [Based on "family"]
Number of orders and names [Based on "order"]
Number of classes and names [Based on "class"]
Number of phylums and names [Based on "phylum"]
Number of kingdoms and names [Based on "kingdom"]
Number of countries and names [Based on "country"]
Bounding Box (Latitude and Longitude) [Based on "decimalLatitude" and "decimalLongitude"]
Oldest and Newest Records [Based on "eventDate" | The date must start with the year, for example "yyyy-MM-dd"]

#####Regarding the species count:####
All individual values in the acceptedNameUsage are counted.
This means that a species identified only as "Animalia" will count as +1.
if you do not wish to count species only identified at the Kingdom, Phylum, etc, level
look at the species name list and adjust accordingly.
				
To use, edit the "MetadataExtractor Runner (EDIT ME).bat" with notepad and change the "Input File" into your input file 
and "Output File" to where you wish to save the results (both with quotes).
Save the file.
Then, double click "MetadataExtractor Runner (EDIT ME).bat" 
and a window should appear showing the progress.

Example:
java -jar MetadataExtractor.jar "C:/input file.csv" "C:/output file.txt"