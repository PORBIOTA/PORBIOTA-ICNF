Creates a .CSV by converting MGRS coordinates to decimal Longitude and Latitude.

####################################IMPORTANT############################################
 The input file can have any number of columns, but the MGRS column must be named "MGRS".
#########################################################################################


The order and number of rows of the results is preserved, so simply joining the produced table to the original one is OK.
			
To use, edit the "MGRStoLongLat Runner (EDIT ME).bat" with notepad and change the "Input File.csv" into your input file 
and "Output File.csv" to where you wish to save the results (both with quotes). 
Then, the UTM Zone of the coordinates. If already included in the .csv, simply add ""
Save the file.
Then, double click "MGRStoLongLat Runner (EDIT ME).bat" 
and a window should appear showing the progress.

Example:
java -jar LocationExtractor.jar "C:/input file.csv" "C:/output file.csv" "29S"
java -jar LocationExtractor.jar "C:/input file.csv" "C:/output file.csv" ""

The output file is in UTF-8.
