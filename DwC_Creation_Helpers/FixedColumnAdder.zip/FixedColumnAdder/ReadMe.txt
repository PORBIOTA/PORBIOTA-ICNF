Creates a .CSV by adding the following columns to the given .csv:

    collectionCode
    type
    modified
    license
    institutionID
    institutionCode
    datasetName
    basisOfRecord
    occurrenceStatus
			
To use, edit the "FixedColumnAdder Runner (EDIT ME).bat" with notepad and change the "Input File.csv" into your input file 
and "Output File.csv" to where you wish to save the results (both with quotes). 
Then, add in the order given the terms for each of the columns.
Save the file.
Then, double click "FixedColumnAdder Runner (EDIT ME).bat" 
and a window should appear showing the progress.

Example:
java -jar LocationExtractor.jar "C:/input file.csv" "C:/output file.csv" "collectionCode" "type" "modified" "license" "institutionID" "institutionCode" "datasetName" "basisOfRecord" "occurrenceStatus"

The output file is in UTF-8.
