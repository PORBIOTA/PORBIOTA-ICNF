Creates a UTF-8 CSV by merging two or more CSVs together.

Its purpose is to join equal size CSVs, so it only creates as many lines as the ones in the smallest CSV. 
		
To use, edit the "TableJoiner Runner (EDIT ME).bat" with notepad and change add the names of your input files
and change "Output File.csv" to where you wish to save the results (both with quotes). Then, double click "TaleJoiner Runner (EDIT ME).bat" 
and a window should appear showing the progress (most likely instant).

Example:
java -jar LocationExtractor.jar "C:\input file 1.csv" "C:\input file 2.csv" "C:\output file.csv"
java -jar LocationExtractor.jar "C:\input file 1.csv" "C:\input file 2.csv" "C:\input file 3.csv" "C:\input file 4.csv" "C:\output file.csv"

